package ca.unb.mobiledev.task_village_take2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.widget.ListView;

import java.util.List;

public class TaskListActivity extends AppCompatActivity {

    private TaskViewModel taskViewModel;
    private TaskAdapter taskAdapter;
    private ListView taskListV;

    private String priority;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);
        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);
        taskListV = (ListView)findViewById(R.id.listview);
        priority = getIntent().getExtras().getString(ChooseTaskType.PRIO_CODE);
        getTasks(priority);
    }

    private void getTasks(String priority)
    {
        final LiveData<List<Task>> tasksData = taskViewModel.getTasksByPrio(priority);
        tasksData.observe(this, new Observer<List<Task>>() {
            @Override
            public void onChanged(List<Task> tasks) {
                if(tasks != null)
                {
                   taskAdapter = new TaskAdapter(getApplicationContext(), tasks);
                   taskListV.setAdapter(taskAdapter);
                }
                taskAdapter.notifyDataSetChanged();
            }
        });
    }
}