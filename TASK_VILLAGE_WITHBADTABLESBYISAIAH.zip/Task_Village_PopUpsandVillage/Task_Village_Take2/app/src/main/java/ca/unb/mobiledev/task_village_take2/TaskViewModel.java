package ca.unb.mobiledev.task_village_take2;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class TaskViewModel extends AndroidViewModel {
    private TaskRepository taskRepository;

    public TaskViewModel(@NonNull Application application) {
        super(application);
        taskRepository = new TaskRepository(application);
    }

    public void addTask(String name, String desc, String prio, String type, String deadline)
    {
        taskRepository.insertRecord(name, desc, prio, type, deadline);
    }

    public LiveData<List<Task>> getTasksByPrio(String prio)
    {
        return taskRepository.getTasks(prio);
    }

    public int getTaskNumByPrio(String prio)
    {
        return taskRepository.getTaskCount(prio);
    }

    public void completeTask(int id)
    {
        taskRepository.completeTask(id);
    }

}

