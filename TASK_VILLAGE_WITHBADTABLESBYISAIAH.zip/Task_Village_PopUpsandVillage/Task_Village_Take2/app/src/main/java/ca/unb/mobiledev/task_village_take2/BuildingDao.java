package ca.unb.mobiledev.task_village_take2;

import androidx.room.Dao;
import androidx.room.Ignore;
import androidx.room.Insert;

import static androidx.room.OnConflictStrategy.IGNORE;

@Dao
public interface BuildingDao {

    @Insert(onConflict = IGNORE)
    void insert(building building);

}
