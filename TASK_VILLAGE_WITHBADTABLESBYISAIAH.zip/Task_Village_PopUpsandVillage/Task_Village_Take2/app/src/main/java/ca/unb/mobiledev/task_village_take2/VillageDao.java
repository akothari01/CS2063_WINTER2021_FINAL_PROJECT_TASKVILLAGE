package ca.unb.mobiledev.task_village_take2;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import static androidx.room.OnConflictStrategy.IGNORE;

@Dao
public interface VillageDao {


    @Insert(onConflict = IGNORE)
    void insert(Village village);

    @Query("SELECT VillageName FROM Villages WHERE ")



}
