package ca.unb.mobiledev.task_village_take2;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import static java.lang.Boolean.TRUE;

@Entity(tableName = "buildings")
public class building {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    @ColumnInfo(name = "Image Codes")
    private int image;

    @ColumnInfo(name = "Inhabitants")
    private String inhabitant;
    randomName rand = new randomName();

    @ColumnInfo(name = "Village Belonged To")
    private Village belongsTo;

    public building(int image, Village belongsTo){

        this.image = image;
        this.inhabitant = rand.randomName();
        this.belongsTo = belongsTo;
    }

    public int getImage(){
        return image;
    }

    public String getInhabitant(){
        return inhabitant;
    }


}
