package ca.unb.mobiledev.task_village_take2;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.util.ArrayList;

@Entity(tableName = "Villages")

public class Village implements Serializable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    public void setId(int id){
        this.id = id;
    }

    public int getId(){ return id;}

    @ColumnInfo(name = "VillageName")
    private String vilName;

    @ColumnInfo(name = "addNext")
    private boolean addNext;

    public Village(String vilName){
        this.vilName = vilName;
    }

    public boolean getAdd(){
        return addNext;
    }

    public void setAdd(boolean addNext){
        this.addNext = addNext;
    }

    public String getVilName(){
        return vilName;
    }

    @Override
    public String toString(){
        String printed = "";
        printed += this.vilName;
        return printed;
    }

}
