package ca.unb.mobiledev.task_village_take2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.Date;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Task> tasks;
    //private ArrayAdapter<Task> itemsAdapter;
    //private ListView listView; an older implementation.
    private MyAdapter itemsAdapter;
    private RecyclerView recyclerView;
    private Button button;
    private ImageView imageView;
    private final String tag = "MainActivity TaskMenu: ";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(tag, "onCreate called");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //listView = findViewById(R.id.listviewID); an older implementation.
        recyclerView = findViewById(R.id.recycler);
        button = findViewById(R.id.button);
        imageView = findViewById(R.id.imageView);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //addItem(v);
                Intent intent = new Intent(MainActivity.this, CreateTaskActiviy.class);
                startActivityForResult(intent, 1);

            }
        });

        tasks = new ArrayList<>();
        //itemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, Tasks);
        itemsAdapter = new MyAdapter(tasks);
        recyclerView.setAdapter(itemsAdapter);

        //setUpListViewListener();



    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        Log.i(tag, "onActivityResult called");
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode == 1)
        {
            if(resultCode == RESULT_OK)
            {
                String nameTask = intent.getStringExtra("nameTask");
                DateFormat format = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                Date currentDate = new Date();
                Task newTask = new Task(nameTask, currentDate);
                System.out.println(newTask.toString());
                tasks.add(newTask);
                //itemsAdapter.addItemsToList(newTask);
                itemsAdapter.notifyDataSetChanged();
            }
        }
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>
    {
        private ArrayList<Task> mDataSet;
        public MyAdapter(ArrayList<Task> myDataSet){
            mDataSet = myDataSet;
        }
        public class ViewHolder extends RecyclerView.ViewHolder
        {
            public CardView mCardView;
            public TextView textView;
            public ImageButton imageButton;
            public ViewHolder(CardView v)
            {
                super(v);
                mCardView = v;
                textView = v.findViewById(R.id.dacardtext);
                imageButton = v.findViewById(R.id.imageButton);
            }
        }

        public void addItemsToList(Task task)
        {
            Log.i(tag, "addItemsToList called");
            mDataSet.add(task);
        }


        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            CardView v = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Log.i(tag, "onBindViewHolderCalled");
            final Task task = mDataSet.get(position);
            holder.textView.setText(task.toString());
            holder.imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Task removed = mDataSet.get(position);
                    mDataSet.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position,getItemCount());
                }
            });
        }

        @Override
        public int getItemCount() {
            return mDataSet.size();
        }
    }

    /**
    private void setUpListViewListener() {

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Context context = getApplicationContext();
                Toast.makeText(context, "Task Cancelled", Toast.LENGTH_LONG).show();
                Tasks.remove(position);
                itemsAdapter.notifyDataSetChanged();
                return true;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Context context = getApplicationContext();
                Toast.makeText(context,"Task Completed!", Toast.LENGTH_LONG).show();
                Tasks.remove(position);
                itemsAdapter.notifyDataSetChanged();


            }
        });


    }
     */
/**
    private void addItem(View v) {

        Context context = getApplicationContext();



        EditText input = findViewById(R.id.editTextTaskName);
        DateFormat format = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date currentDate = new Date();


        String itemText = input.getText().toString();
        Task newTask = new Task(itemText, currentDate);

        if(!(itemText.equals(""))){
            itemsAdapter.add(newTask);
            input.setText("");
        }

        else{
            Toast.makeText(context, "New Tasks need a name", Toast.LENGTH_LONG).show();
        }


    }

*/
}