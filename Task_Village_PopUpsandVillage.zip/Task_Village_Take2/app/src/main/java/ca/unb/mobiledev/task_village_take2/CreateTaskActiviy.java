package ca.unb.mobiledev.task_village_take2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateTaskActiviy extends AppCompatActivity {

    private Button createBtn;
    private Button cancelBtn;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task_activiy);

        createBtn = findViewById(R.id.button2);
        cancelBtn = findViewById(R.id.button3);
        editText = findViewById(R.id.editTextTextPersonName);
        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = getApplicationContext();
                String taskName = editText.getText().toString();
                if(!(taskName.equals(""))){
                    Intent intent = new Intent();
                    intent.putExtra("nameTask", taskName);
                    setResult(RESULT_OK, intent);
                    finish();
                }
                else{
                    Toast.makeText(context, "New Tasks need a name", Toast.LENGTH_LONG).show();
                }
            }
        });
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}