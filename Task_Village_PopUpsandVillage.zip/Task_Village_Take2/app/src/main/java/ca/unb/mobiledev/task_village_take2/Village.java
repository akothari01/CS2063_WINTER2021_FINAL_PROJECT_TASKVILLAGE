package ca.unb.mobiledev.task_village_take2;

import java.util.ArrayList;

public class Village {

    private String vilName;
    private ArrayList<building> buildingList;

    public Village(String vilName){
        this.vilName = vilName;
        buildingList = new ArrayList<building>();
    }

    public String getVilName(){
        return vilName;
    }

    public ArrayList<building> getBuildings(){
        return buildingList;
    }

    public void add(building newBuild){
        buildingList.add(newBuild);
    }



}
