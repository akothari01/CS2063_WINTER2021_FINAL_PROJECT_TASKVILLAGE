/**
package ca.unb.mobiledev.task_village_take2;

import android.media.Image;

import java.awt.*;

public class drawVillage {

    


}
*/