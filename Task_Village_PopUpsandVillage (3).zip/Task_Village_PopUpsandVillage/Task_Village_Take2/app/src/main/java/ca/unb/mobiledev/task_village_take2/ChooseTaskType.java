package ca.unb.mobiledev.task_village_take2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class ChooseTaskType extends AppCompatActivity implements View.OnClickListener{

    private Button urim;
    private Button urnim;
    private Button nurim;
    private Button nurnim;

    private TaskViewModel taskViewModel;

    public static final String PRIO_CODE = "priorityCode";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_task_type);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        urim = (Button)findViewById(R.id.button7);
        urnim = (Button)findViewById(R.id.button6);
        nurim = (Button)findViewById(R.id.button4);
        nurnim = (Button)findViewById(R.id.button8);

        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);
        /**
        urim.setText("Urgent and Important" + "\n" + taskViewModel.getTaskNumByPrio("Urgent and Important"));
        urnim.setText("Urgent and not Important" + "\n" +
                taskViewModel.getTaskNumByPrio("Urgent and not Important"));
        nurim.setText("Not Urgent but Important" + "\n" + taskViewModel.getTaskNumByPrio("Not Urgent but Important"));
        nurnim.setText("Not Urgent and not Important" + "\n" +
                taskViewModel.getTaskNumByPrio("Not Urgent and not Important"));
         */
        urim.setOnClickListener(this);
        urnim.setOnClickListener(this);
        nurim.setOnClickListener(this);
        nurnim.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(ChooseTaskType.this, TaskListActivity.class);
        intent.putExtra("ID", getIntent().getStringExtra("villageID"));
        switch (view.getId())
        {
            case(R.id.button7):
                intent.putExtra(ChooseTaskType.PRIO_CODE, "Urgent and Important");
                break;
            case(R.id.button6):
                intent.putExtra(ChooseTaskType.PRIO_CODE, "Urgent and not Important");
                break;
            case(R.id.button4):
                intent.putExtra(ChooseTaskType.PRIO_CODE, "Not Urgent but Important");
                break;
            case(R.id.button8):
                intent.putExtra(ChooseTaskType.PRIO_CODE, "Not Urgent and not Important");
                break;
        }
        startActivity(intent);
    }
}